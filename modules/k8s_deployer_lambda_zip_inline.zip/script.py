print("dummy code. The lambda provisioning happens in the Bastion host's userdata due to an dependancy package needed")
